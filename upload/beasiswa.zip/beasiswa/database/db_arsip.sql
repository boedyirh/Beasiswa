-- MySQL dump 10.13  Distrib 5.6.35, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: db_arsip
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_arsip`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_arsip` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_arsip`;

--
-- Table structure for table `bsw_jenis`
--

DROP TABLE IF EXISTS `bsw_jenis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bsw_jenis` (
  `BeasiswaID` int(4) NOT NULL AUTO_INCREMENT,
  `Kode` varchar(8) NOT NULL,
  `Nama` varchar(250) NOT NULL,
  `Jenis` varchar(250) NOT NULL,
  `Tgl_mulai` date NOT NULL,
  `Tgl_selesai` date NOT NULL,
  `Besaran` int(11) NOT NULL,
  `Periode` varchar(50) NOT NULL,
  `Kuota` int(11) NOT NULL,
  `IPKMinimal` decimal(4,2) NOT NULL,
  `SemesterMinimal` int(11) NOT NULL,
  `SKSMinimal` int(11) NOT NULL,
  `AktifKemahasiswaan` enum('Y','N') NOT NULL DEFAULT 'Y',
  `TidakMampu` enum('Y','N') NOT NULL DEFAULT 'Y',
  `BeasiswaLain` enum('Y','N') NOT NULL DEFAULT 'Y',
  `SyaratLain` mediumtext NOT NULL,
  `File` varchar(200) NOT NULL DEFAULT 'Y',
  `Deskripsi` mediumtext NOT NULL,
  `Status` varchar(40) NOT NULL DEFAULT '',
  `IsDeleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `Inputby` varchar(90) NOT NULL,
  `TanggalInput` date NOT NULL,
  `NA` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`BeasiswaID`),
  UNIQUE KEY `Kode` (`Kode`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bsw_jenis`
--

LOCK TABLES `bsw_jenis` WRITE;
/*!40000 ALTER TABLE `bsw_jenis` DISABLE KEYS */;
INSERT INTO `bsw_jenis` VALUES (11,'18BMS','Bidik Misi Reguler 2018','BMS','2018-01-01','2018-01-01',0,'2018',0,0.00,0,0,'','','','','','','1','N','','0000-00-00','N'),(12,'18BMK','Bidik Misi Khusus 2018','BMS','2018-01-01','2018-01-31',0,'2018',0,3.00,2,2,'N','N','N','','','','1','N','','0000-00-00','N'),(13,'18YYS','Beasiswa Yayasan 2018','YYS','2018-01-01','2018-12-31',0,'2018',0,3.00,5,110,'N','N','N','Tidak Ada','','Beasiswa Untuk Mahasiswa IKIP PGRI Bojonegoro','1','N','','0000-00-00','N'),(14,'19PPA','Beasiswa PPA 2019','PPA','2018-12-02','2018-12-02',0,'2019',0,3.00,3,123,'N','','N','Test','','Test','0','N','','0000-00-00','N'),(15,'PNP','Penampung','LLN','1970-01-01','1970-01-01',0,'2018',0,0.00,0,0,'N','N','N','Hanya Penampung','','Hanya Penampung','1','N','','0000-00-00','N');
/*!40000 ALTER TABLE `bsw_jenis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bsw_pemohon`
--

DROP TABLE IF EXISTS `bsw_pemohon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bsw_pemohon` (
  `PemohonID` int(4) NOT NULL AUTO_INCREMENT,
  `BeasiswaID` varchar(50) NOT NULL,
  `Periode` varchar(50) NOT NULL,
  `Nama` varchar(250) NOT NULL,
  `JenisKelamin` varchar(4) NOT NULL,
  `MhswID` varchar(10) NOT NULL,
  `IPK` decimal(4,2) NOT NULL,
  `SKSLulus` int(3) NOT NULL,
  `Semester` int(2) NOT NULL,
  `Alamat` varchar(250) NOT NULL,
  `NoHP` varchar(20) NOT NULL,
  `Keterangan` varchar(250) NOT NULL,
  `PekerjaanOrtu` varchar(2) NOT NULL,
  `TanggunganOrtu` varchar(50) NOT NULL,
  `PenghasilanOrtu` varchar(50) NOT NULL,
  `Prestasi` varchar(300) NOT NULL,
  `File` varchar(200) NOT NULL DEFAULT 'Y',
  `Status` varchar(3) NOT NULL DEFAULT '10',
  `ProdiID` varchar(40) NOT NULL DEFAULT '',
  `KodePT` varchar(40) NOT NULL DEFAULT '',
  `JenjangStudi` varchar(40) NOT NULL DEFAULT '',
  `TempatLahir` varchar(40) NOT NULL DEFAULT '',
  `TanggalLahir` date NOT NULL,
  `TanggalPengajuan` date NOT NULL,
  `InputBy` varchar(100) NOT NULL DEFAULT 'Ayu',
  `TanggalInput` date NOT NULL,
  `IsDeleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`PemohonID`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bsw_pemohon`
--

LOCK TABLES `bsw_pemohon` WRITE;
/*!40000 ALTER TABLE `bsw_pemohon` DISABLE KEYS */;
INSERT INTO `bsw_pemohon` VALUES (25,'12','2018','MAULIDIYATUL MUNAWAROH','P','18210020',0.00,0,0,'Ds. Sarirejo RT 06/RW 02 Kec. Balen Kab. Bojonegoro','085796710021','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-06-16','0000-00-00','Ayu','0000-00-00','N','N'),(24,'12','2018','DENY ADIB WAHYUDI','L','18220004',0.00,0,0,'Ds. Sendangrajo RT 01/RW 01 Kec. Dander Kab. Bojonegoro','085853986780','','xx','','','','','11','87-205','072011','5','BOJONEGORO','1998-06-16','0000-00-00','Ayu','0000-00-00','N','N'),(23,'12','2018','RISTA APRILLIA','P','18310019',0.00,0,0,'Ds. Pilangsari Dk. Jambe RT 09/RW 03 Kec. Kalitidu Kab. Bojonegoro','085203680425','','xx','','','','','11','84-202','072011','5','BOJONEGORO','2000-04-25','0000-00-00','Ayu','0000-00-00','N','N'),(26,'12','2018','NISA ROMADHONA','P','18210023',0.00,0,0,'Ds. Jatisari RT 10/RW 04 Kec. Senori Kab. Tuban','081249578118','','xx','','','','','11','87-203','072011','5','TUBAN','1998-01-07','0000-00-00','Ayu','0000-00-00','N','N'),(27,'12','2018','ADE FIRMANSYAH','L','18210002',0.00,0,0,'Ds. Sumberarum RT 21/RW 07 Kec. Dander Kab. Bojonegoro','081217321043','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-04-12','0000-00-00','Ayu','0000-00-00','N','N'),(28,'12','2018','ARI WAHYU MUSTAKIM','L','18210004',0.00,0,0,'Ds. Sobontoro RT 05/RW 01 Kec. Balen Kab. Bojonegoro','085331078275','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-06-16','0000-00-00','Ayu','0000-00-00','N','N'),(29,'12','2018','ALIFIA BRILLIANDA NUR FAUZIAH','P','18310003',0.00,0,0,'Ds. Ringin Tunggal RT 04/RW 01 Kec. Gayam Kab. Bojonegoro','085546778160','','xx','','','','','11','84-202','072011','5','BOJONEGORO','2000-07-17','0000-00-00','Ayu','0000-00-00','N','N'),(30,'12','2018','IMA KULAMA GUTAMI','P','18120042',0.00,0,0,'Ds. Sidomukti Dk. Pandelegan RT 02/RW 01 Kec. Kepohbaru Kab. Bojonegoro','085836311023','','xx','','','','','11','88-203','072011','5','SURABAYA','1999-10-07','0000-00-00','Ayu','0000-00-00','N','N'),(31,'12','2018','DEWI RATNA SWARI','P','18120006',0.00,0,0,'Ds. Ngumpakdalem Kec. Dander Kab. Bojonegoro','085746414058','','xx','','','','','11','88-203','072011','5','BOJONEGORO','1999-02-20','0000-00-00','Ayu','0000-00-00','N','N'),(32,'12','2018','WAHID ROMADHON','L','18120059',0.00,0,0,'Ds. Balun RT 01/RW 05 Kec. Cepu Kab. Blora','085743658890','','xx','','','','','11','88-203','072011','5','BLORA','2000-11-18','0000-00-00','Ayu','0000-00-00','N','N'),(33,'12','2018','LUCKYANTO HANAFIE','L','18110047',0.00,0,0,'Ds. Brabowan Kec. Gayam Kab. Bojonegoro','082230707863','','xx','','','','','11','88-201','072011','5','BOJONEGORO','2000-03-24','0000-00-00','Ayu','0000-00-00','N','N'),(35,'12','2018','INDI NAILA FARA MAULIA HANA','P','18120045',0.00,0,0,'Ds. Pelem Kec. Purwosari Kab. Bojonegoro','081335781635','','xx','','','','','11','88-203','072011','5','BOJONEGORO','2000-09-09','0000-00-00','Ayu','0000-00-00','N','N'),(36,'12','2018','SITI NURUL KHOTIMAH','P','18310025',0.00,0,0,'Ds. Ketuwan RT 05/RW 01 Kec. Kedungtuban Kab. Blora','085608569180','','xx','','','','','11','84-202','072011','5','BLORA','2001-02-09','0000-00-00','Ayu','0000-00-00','N','N'),(37,'12','2018','DIAH AYU SUKMA','P','18210011',0.00,0,0,'Ds. Ngampal RT 03/RW 01 Kec. Sumberrejo Kab. Bojonegoro','085843997621','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-08-25','0000-00-00','Ayu','0000-00-00','N','N'),(38,'12','2018','SASA NOVIA NANDA','P','18210031',0.00,0,0,'Ds. Krodonan RT 16/RW 05 Kec. Gondang Kab. Bojonegoro','0852327071118','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-02-15','0000-00-00','Ayu','0000-00-00','N','N'),(39,'12','2018','SA\'IN NOVIANA','P','18310022',0.00,0,0,'Ds. Sumber Dk. Jati RT 01/RW 06 Kec. Kradenan Kab. Blora','082243877385','','xx','','','','','11','84-202','072011','5','BLORA','1999-11-29','0000-00-00','Ayu','0000-00-00','N','N'),(40,'12','2018','TIKA ZAHROTIN','P','18310026',0.00,0,0,'Ds. Mulung RT 05/RW 01 Kec. Kedungadem Kab. Bojonegoro','085704717805','','xx','','','','','11','84-202','072011','5','BOJONEGORO','2000-08-01','0000-00-00','Ayu','0000-00-00','N','N'),(41,'12','2018','YUDHA PRATAMA','L','18210040',0.00,0,0,'Ds. Seganter Dk. Banjar RT 11/RW 03 Kec. Gondang Kab. Bojonegoro','081259891461','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2001-09-15','0000-00-00','Ayu','0000-00-00','N','N'),(42,'12','2018','M. KHUSNUN NAJIH','L','18210019',0.00,0,0,'Ds. Leran RT 20/RW 06 Kec. Kalitidu Kab. Bojonegoro','085606339520','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-08-11','0000-00-00','Ayu','0000-00-00','N','N'),(43,'12','2018','LUTHFIANI FAUZIYAH','P','18210018',0.00,0,0,'Dsn. Jintel RT 07/RW 08 Kec. Kedungadem Kab. Bojonegoro','085203866324','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-05-16','0000-00-00','Ayu','0000-00-00','N','N'),(44,'12','2018','RICKY WAHYU RUDIANSYAH','L','18210028',0.00,0,0,'Ds. Lengkong RT 06/RW 01 Kec. Balen Kab. Bojonegoro','18210028','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2001-01-21','0000-00-00','Ayu','0000-00-00','N','N'),(45,'12','2018','SITI NUR MUKHOLIFAH','P','17220015',0.00,0,0,'Ds. Kedaton RT 15/RW 02 Kec. Kapas Kab. Bojonegoro','088217664661','','xx','','','','','11','87-205','072011','5','BOJONEGORO','1999-11-11','0000-00-00','Ayu','0000-00-00','N','N'),(46,'12','2018','BRIANT AGUSTI BRAMASTYA','L','18210041',0.00,0,0,'Ds. Sukorame RT 08/RW 01 Kec. Sukorame Kab. Lamongan','085855725565','','xx','','','','','11','87-203','072011','5','LAMONGAN','1999-08-18','0000-00-00','Ayu','0000-00-00','N','N'),(47,'12','2018','TONI AHMAD','L','18210036',0.00,0,0,'Ds. Tanggel Dk. Suru RT 03/RW 04 Kec. Randublatung Kab. Blora','085700930926','','xx','','','','','10','87-203','072011','5','BLORA','2001-01-22','0000-00-00','Ayu','0000-00-00','N','N'),(48,'12','2018','ALFI NOFITA SARI','P','18310002',0.00,0,0,'Ds. Ngampal Dk. Ngajen RT 08/RW 02 Kec. Sumberrejo Kab. Bojonegoro','085855416593','','xx','','','','','11','84-202','072011','5','BOJONEGORO','1999-10-14','0000-00-00','Ayu','0000-00-00','N','N'),(49,'12','2018','AMRIZAL FEBRIANZAH','L','18210003',0.00,0,0,'Ds. Babad RT 01/RW 01 Kec. Kedungadem Kab. Bojonegoro','081234185062','','xx','','','','','11','87-203','072011','5','BOJONEGORO','2000-02-08','0000-00-00','Ayu','0000-00-00','N','N'),(50,'13','2018','SANTIKA YONA HARIYANTI','P','18210030',0.00,0,0,'Ds. Genjahan RT 01/RW 01 Kec. Jiken Kab. Blora','085326286700','','xx','','','','','11','87-203','072011','5','BLORA','1999-09-25','0000-00-00','Ayu','0000-00-00','N','N'),(54,'','-','blblsbl','','',0.00,0,0,'','','','','','','','','Pen','','','','','0000-00-00','0000-00-00','Ayu','0000-00-00','N','N');
/*!40000 ALTER TABLE `bsw_pemohon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bsw_periode`
--

DROP TABLE IF EXISTS `bsw_periode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bsw_periode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PeriodeID` varchar(4) NOT NULL,
  `Tahun` varchar(4) NOT NULL,
  `Status` varchar(2) NOT NULL DEFAULT '1',
  `NA` enum('Y','N') NOT NULL DEFAULT 'N',
  `IsDeleted` varchar(2) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `PeriodeID` (`PeriodeID`)
) ENGINE=MyISAM AUTO_INCREMENT=2024 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bsw_periode`
--

LOCK TABLES `bsw_periode` WRITE;
/*!40000 ALTER TABLE `bsw_periode` DISABLE KEYS */;
INSERT INTO `bsw_periode` VALUES (2020,'2016','2016','1','N','N'),(2021,'2017','2017','1','N','N'),(2022,'2018','2018','1','N','N'),(2023,'2019','2019','1','N','N');
/*!40000 ALTER TABLE `bsw_periode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_sessions`
--

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daftar_sesi`
--

DROP TABLE IF EXISTS `daftar_sesi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daftar_sesi` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `NamaForm` varchar(50) NOT NULL,
  `NamaSesi` varchar(50) NOT NULL,
  `ValueSesi` varchar(50) NOT NULL,
  `UserLogin` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daftar_sesi`
--

LOCK TABLES `daftar_sesi` WRITE;
/*!40000 ALTER TABLE `daftar_sesi` DISABLE KEYS */;
INSERT INTO `daftar_sesi` VALUES (1,'beasiswa_disetujui','BeasiswaID','13','1'),(2,'pengajuan_beasiswa','BeasiswaID','xx','1'),(3,'pengajuan_beasiswa','BeasiswaID','11','2'),(4,'beasiswa_disetujui','BeasiswaID','12','2');
/*!40000 ALTER TABLE `daftar_sesi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mhsw`
--

DROP TABLE IF EXISTS `mhsw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mhsw` (
  `MhswID` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Login` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `KelasID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TahunID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `LevelID` int(11) NOT NULL DEFAULT '120',
  `NoPolisAsuransi` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `AwalAsuransi` date DEFAULT NULL,
  `ExpiredAsuransi` date DEFAULT NULL,
  `NoKTP` varchar(20) COLLATE latin1_general_ci DEFAULT 'N',
  `NamaIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `ProdiID` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Password` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TxtPassword` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `KDPIN` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `PMBID` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `PMBFormJualID` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `BerkasPMB1` enum('I','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas Ijazah',
  `BerkasPMB2` enum('T','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas Transkrip',
  `BerkasPMB3` enum('A','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas Akta IV',
  `BerkasPMB4` enum('K','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas Surat Keterangan',
  `BerkasPMB5` enum('D','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas SK Konversi',
  `BerkasPMB6` enum('L','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N' COMMENT 'Berkas Lain lain',
  `BerkasLulus1` enum('I','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `BerkasLulus2` enum('T','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `BerkasLulus3` enum('A','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `BerkasLulus4` enum('L','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `PSSBID` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `NIRM` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `NIMAN` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `BuktiSetoran` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `KodeID` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'SISFO',
  `BIPOTID` int(11) NOT NULL DEFAULT '0',
  `Autodebet` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Foto` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `StatusAwalID` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusMhswID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `MasaStudi` int(2) DEFAULT '0',
  `ProgramID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PenasehatAkademik` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Kelamin` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `WargaNegara` char(3) COLLATE latin1_general_ci DEFAULT 'WNI',
  `Kebangsaan` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TempatLahir` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusSipil` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `TinggiBadan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `BeratBadan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` text COLLATE latin1_general_ci,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RT` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RW` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePos` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Propinsi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Negara` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telephone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Handphone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatAsal` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RTAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RWAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TeleponAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AnakKe` int(11) NOT NULL DEFAULT '1',
  `JumlahSaudara` int(11) NOT NULL DEFAULT '1',
  `NamaAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaAyah` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanAyah` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupAyah` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaIbu` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanIbu` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanIbu` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupIbu` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatOrtu` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RTOrtu` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RWOrtu` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TeleponOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HandphoneOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `EmailOrtu` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanTerakhir` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaSekolah` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `KodeArea` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `AsalSekolah1` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JenisSekolahID` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatSekolah` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JurusanSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NilaiSekolah` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TahunLulus` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `IjazahSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalPT` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Yudisium` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NamaPT` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `MhswIDAsalPT` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ProdiAsalPT` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `LulusAsalPT` enum('Y','N') COLLATE latin1_general_ci DEFAULT NULL,
  `TglLulusAsalPT` date DEFAULT NULL,
  `IPKAsalPT` decimal(4,2) NOT NULL DEFAULT '0.00',
  `Pilihan1` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Pilihan2` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Pilihan3` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `BatasStudi` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Harga` double NOT NULL DEFAULT '0',
  `SudahBayar` enum('Y','N','R') COLLATE latin1_general_ci DEFAULT 'N',
  `TanggalUjian` date DEFAULT NULL,
  `LulusUjian` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `RuangID` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `NomerUjian` int(11) DEFAULT NULL,
  `NilaiUjian` float unsigned NOT NULL DEFAULT '0',
  `GradeNilai` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLulus` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Lulus dari perguruan tinggi',
  `SdhAmbilIjazah` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Syarat` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `SyaratLengkap` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `BuktiSetoranMhsw` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  `TanggalSetoranMhsw` date DEFAULT NULL,
  `TotalBiaya` bigint(20) NOT NULL DEFAULT '0',
  `TotalBayar` bigint(20) NOT NULL DEFAULT '0',
  `Dispensasi` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `DispensasiID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JudulDispensasi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `CatatanDispensasi` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaBank` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NomerRekening` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `IPK` decimal(4,2) NOT NULL DEFAULT '0.00',
  `IPKLapor` decimal(4,2) NOT NULL DEFAULT '2.00',
  `TotalSKS` int(11) NOT NULL DEFAULT '0',
  `TotalSKSPindah` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `WisudaID` bigint(20) NOT NULL DEFAULT '0',
  `TAID` bigint(20) NOT NULL DEFAULT '0',
  `Predikat` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `SKPenyetaraan` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `TglSKPenyetaraan` datetime NOT NULL,
  `SKMasuk` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSKMasuk` date DEFAULT NULL,
  `Keluar` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `SKKeluar` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `NoIjazah` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `TglSKKeluar` date NOT NULL DEFAULT '0000-00-00',
  `TahunKeluar` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `CatatanKeluar` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NoIdentitas` bigint(20) NOT NULL DEFAULT '0',
  `NoFakultas` bigint(20) NOT NULL DEFAULT '0',
  `NoProdi` bigint(20) NOT NULL DEFAULT '0',
  `TglAmbil_Ijazah` date NOT NULL DEFAULT '0000-00-00',
  `TotalSKS_` int(11) NOT NULL,
  `LoginBuat` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalBuat` datetime DEFAULT NULL,
  `LoginEdit` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalEdit` datetime DEFAULT NULL,
  `TanggalKeluar` date DEFAULT '0000-00-00',
  PRIMARY KEY (`MhswID`),
  KEY `Login` (`Login`),
  KEY `NIRM` (`NIRM`),
  KEY `TahunID` (`TahunID`),
  KEY `KodeID` (`KodeID`),
  KEY `BIPOTID` (`BIPOTID`),
  KEY `StatusAwalID` (`StatusAwalID`),
  KEY `StatusMhswID` (`StatusMhswID`),
  KEY `ProgramID` (`ProgramID`),
  KEY `ProdiID` (`ProdiID`),
  KEY `PenasehatAkademik` (`PenasehatAkademik`),
  KEY `Kelamin` (`Kelamin`),
  KEY `Keluar` (`Keluar`),
  KEY `NIMAN` (`NIMAN`),
  KEY `TahunKeluar` (`TahunKeluar`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Tabel Mhsw';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mhsw`
--

LOCK TABLES `mhsw` WRITE;
/*!40000 ALTER TABLE `mhsw` DISABLE KEYS */;
/*!40000 ALTER TABLE `mhsw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_klasifikasi`
--

DROP TABLE IF EXISTS `ref_klasifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ref_klasifikasi` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `uraian` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_klasifikasi`
--

LOCK TABLES `ref_klasifikasi` WRITE;
/*!40000 ALTER TABLE `ref_klasifikasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_klasifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_admin`
--

DROP TABLE IF EXISTS `t_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(75) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `level` enum('Super Admin','Admin') NOT NULL,
  `Status` varchar(300) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_admin`
--

LOCK TABLES `t_admin` WRITE;
/*!40000 ALTER TABLE `t_admin` DISABLE KEYS */;
INSERT INTO `t_admin` VALUES (1,'admin','0192023a7bbd73250516f069df18b500','Administrator','19900326 201401 1 002','Super Admin','0'),(2,'umum','adfab9c56b8b16d6c067f8d3cff8818e','Nur Akhwan','19900326 201401 1 002','Admin','0'),(3,'bsw_ayu','fae38bd94701cdf2a9d114425cb40292','Ayu Rektorat','123','Admin','0');
/*!40000 ALTER TABLE `t_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disposisi`
--

DROP TABLE IF EXISTS `t_disposisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disposisi` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_surat` int(6) NOT NULL,
  `kpd_yth` varchar(250) NOT NULL,
  `isi_disposisi` varchar(250) NOT NULL,
  `sifat` enum('Biasa','Segera','Perlu Perhatian Khusus','Perhatian Batas Waktu') NOT NULL,
  `batas_waktu` date NOT NULL,
  `catatan` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disposisi`
--

LOCK TABLES `t_disposisi` WRITE;
/*!40000 ALTER TABLE `t_disposisi` DISABLE KEYS */;
INSERT INTO `t_disposisi` VALUES (1,1,'Kepala TU','ditindaklanjuti','Biasa','2015-05-27','');
/*!40000 ALTER TABLE `t_disposisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grademahasiswa`
--

DROP TABLE IF EXISTS `t_grademahasiswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grademahasiswa` (
  `GradeMahasiswaID` int(4) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(250) NOT NULL,
  `Keterangan` varchar(250) NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`GradeMahasiswaID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grademahasiswa`
--

LOCK TABLES `t_grademahasiswa` WRITE;
/*!40000 ALTER TABLE `t_grademahasiswa` DISABLE KEYS */;
INSERT INTO `t_grademahasiswa` VALUES (1,'Grade A','Grade A','1'),(2,'Grade B','Grade B','1'),(3,'Grade C','Grade C','1'),(4,'Grade D','Grade D','1');
/*!40000 ALTER TABLE `t_grademahasiswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inter_office`
--

DROP TABLE IF EXISTS `t_inter_office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_inter_office` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `no_agenda` varchar(7) NOT NULL,
  `indek_berkas` varchar(100) NOT NULL,
  `isi_ringkas` mediumtext NOT NULL,
  `dari` varchar(250) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inter_office`
--

LOCK TABLES `t_inter_office` WRITE;
/*!40000 ALTER TABLE `t_inter_office` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inter_office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_kumpulan_sk`
--

DROP TABLE IF EXISTS `t_kumpulan_sk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_kumpulan_sk` (
  `SKID` int(6) NOT NULL AUTO_INCREMENT,
  `BeasiswaID` varchar(150) NOT NULL,
  `Periode` varchar(6) NOT NULL,
  `Nama` varchar(200) NOT NULL,
  `NoSK` varchar(7) NOT NULL,
  `File` varchar(200) NOT NULL,
  `Tgl_SK` date DEFAULT NULL,
  `Status` varchar(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`SKID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_kumpulan_sk`
--

LOCK TABLES `t_kumpulan_sk` WRITE;
/*!40000 ALTER TABLE `t_kumpulan_sk` DISABLE KEYS */;
INSERT INTO `t_kumpulan_sk` VALUES (17,'14','2019','Beasiswa PPA 2019','gggggg','','2018-12-21','1');
/*!40000 ALTER TABLE `t_kumpulan_sk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_paket_datang`
--

DROP TABLE IF EXISTS `t_paket_datang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_paket_datang` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `no_agenda` varchar(7) NOT NULL,
  `indek_berkas` varchar(100) NOT NULL,
  `isi_ringkas` mediumtext NOT NULL,
  `dari` varchar(250) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_paket_datang`
--

LOCK TABLES `t_paket_datang` WRITE;
/*!40000 ALTER TABLE `t_paket_datang` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_paket_datang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_paket_kirim`
--

DROP TABLE IF EXISTS `t_paket_kirim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_paket_kirim` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) NOT NULL,
  `no_agenda` varchar(7) NOT NULL,
  `isi_ringkas` mediumtext NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_catat` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_paket_kirim`
--

LOCK TABLES `t_paket_kirim` WRITE;
/*!40000 ALTER TABLE `t_paket_kirim` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_paket_kirim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_periode`
--

DROP TABLE IF EXISTS `t_periode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_periode` (
  `PeriodeID` int(4) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(250) NOT NULL,
  `Status` varchar(4) NOT NULL,
  PRIMARY KEY (`PeriodeID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_periode`
--

LOCK TABLES `t_periode` WRITE;
/*!40000 ALTER TABLE `t_periode` DISABLE KEYS */;
INSERT INTO `t_periode` VALUES (2,'2018','1'),(3,'2019','0'),(4,'2020','0'),(5,'2021','0');
/*!40000 ALTER TABLE `t_periode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_prodi`
--

DROP TABLE IF EXISTS `t_prodi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_prodi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdiID` varchar(10) NOT NULL,
  `Fakultas` varchar(150) NOT NULL,
  `Nama` varchar(250) NOT NULL,
  `KaProdi` varchar(250) NOT NULL,
  `Status` varchar(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ProdiID` (`ProdiID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_prodi`
--

LOCK TABLES `t_prodi` WRITE;
/*!40000 ALTER TABLE `t_prodi` DISABLE KEYS */;
INSERT INTO `t_prodi` VALUES (1,'87-205','FPIPS','Pendidikan Pancasila dan Kewarganegaraan','Ernia','1'),(2,'84-202','FPMIPA','Pendidikan Matematika','Nur Rohman','1'),(3,'88-201','FPBS','Pendidikan Bahasa dan Sastra Indonesia','Solehudin','1'),(4,'87-203','FPIPS','Pendidikan Ekonomi','Fruri Stevani','1'),(5,'88-203','FPBS','Pendidikan Bahasa Inggris','Refi Ranto Rozak','1');
/*!40000 ALTER TABLE `t_prodi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_surat_keluar`
--

DROP TABLE IF EXISTS `t_surat_keluar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_surat_keluar` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `kode` varchar(20) NOT NULL,
  `no_agenda` varchar(7) NOT NULL,
  `isi_ringkas` mediumtext NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_catat` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_surat_keluar`
--

LOCK TABLES `t_surat_keluar` WRITE;
/*!40000 ALTER TABLE `t_surat_keluar` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_surat_keluar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_surat_keputusan`
--

DROP TABLE IF EXISTS `t_surat_keputusan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_surat_keputusan` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nomor` varchar(20) NOT NULL,
  `tahun` varchar(7) NOT NULL,
  `tentang` mediumtext NOT NULL,
  `tgl_surat` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_surat_keputusan`
--

LOCK TABLES `t_surat_keputusan` WRITE;
/*!40000 ALTER TABLE `t_surat_keputusan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_surat_keputusan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_surat_masuk`
--

DROP TABLE IF EXISTS `t_surat_masuk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_surat_masuk` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `no_agenda` varchar(7) NOT NULL,
  `indek_berkas` varchar(100) NOT NULL,
  `isi_ringkas` mediumtext NOT NULL,
  `dari` varchar(250) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `pengolah` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_surat_masuk`
--

LOCK TABLES `t_surat_masuk` WRITE;
/*!40000 ALTER TABLE `t_surat_masuk` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_surat_masuk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr_instansi`
--

DROP TABLE IF EXISTS `tr_instansi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tr_instansi` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kepsek` varchar(100) NOT NULL,
  `nip_kepsek` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr_instansi`
--

LOCK TABLES `tr_instansi` WRITE;
/*!40000 ALTER TABLE `tr_instansi` DISABLE KEYS */;
INSERT INTO `tr_instansi` VALUES (1,'IKIP PGRI Bojonegoro','Jln. Panglima Polim 46 Bojonegoro ','Drs. Sujiran, M.Pd','199003262016011001','logo.png');
/*!40000 ALTER TABLE `tr_instansi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-28 13:40:04
